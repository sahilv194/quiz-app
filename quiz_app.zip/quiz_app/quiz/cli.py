"""Command-line display layer. All quiz rules live in engine.py."""

import argparse
import sys
from pathlib import Path

from .engine import QuizEngine, QuizStateError
from .loader import QuizLoadError, load_questions

DEFAULT_FILE = Path(__file__).resolve().parent.parent / "questions.json"
LETTERS = "ABCDEF"


class QuitQuiz(Exception):
    """User asked to quit (q) or input ended (Ctrl-D / Ctrl-C)."""


def _ask(prompt, input_fn):
    try:
        return input_fn(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        raise QuitQuiz from None


def _show_question(engine, out):
    q = engine.current_question
    print(f"\nQuestion {engine.position} of {engine.total}   (score: {engine.score})", file=out)
    print(q.text, file=out)
    for i, option in enumerate(q.options):
        print(f"  {LETTERS[i]}) {option}", file=out)


def _parse_choice(raw, option_count):
    """Turn 'b', 'B' or '2' into a zero-based index, or None if invalid."""
    raw = raw.strip().upper()
    if len(raw) == 1 and raw in LETTERS[:option_count]:
        return LETTERS.index(raw)
    if raw.isdigit() and 1 <= int(raw) <= option_count:
        return int(raw) - 1
    return None


def _ask_for_answer(engine, input_fn, out):
    """Keep asking until the user gives a valid option. Returns 'restart' or None."""
    count = len(engine.current_question.options)
    while True:
        raw = _ask(f"Your answer (A-{LETTERS[count - 1]}, r = restart, q = quit): ", input_fn)
        if raw.lower() == "q":
            raise QuitQuiz
        if raw.lower() == "r":
            return "restart"
        if raw == "":
            print("Please select an answer before continuing.", file=out)
            continue
        choice = _parse_choice(raw, count)
        if choice is None:
            print(f"'{raw}' is not a valid option. Enter a letter A-{LETTERS[count - 1]}.", file=out)
            continue
        engine.answer(choice)
        return None


def _show_feedback(engine, out):
    result = engine.last_answer
    if result.correct:
        print("Correct!", file=out)
    else:
        print(f"Wrong. The correct answer was {LETTERS[result.correct_index]}) {result.correct_text}", file=out)


def _show_results(engine, out):
    r = engine.result()
    print("\n=== Results ===", file=out)
    print(f"Score: {r.score} / {r.total}  ({r.percent:.0f}%)", file=out)
    print("PASS - well done!" if r.passed else "FAIL - pass mark is 60%. Try again!", file=out)


def play(engine, input_fn=input, out=sys.stdout, title="Quiz"):
    """Run the interactive loop. Returns when the user quits."""
    print(f"=== {title} ===", file=out)
    print(f"This quiz has {engine.total} question{'s' if engine.total != 1 else ''}.", file=out)
    try:
        if _ask("Press Enter to start (q to quit): ", input_fn).lower() == "q":
            print("Goodbye!", file=out)
            return
    except QuitQuiz:
        return
    engine.start()

    try:
        while True:
            while not engine.is_finished:
                _show_question(engine, out)
                if _ask_for_answer(engine, input_fn, out) == "restart":
                    print("\nRestarting quiz...", file=out)
                    engine.restart()
                    continue
                _show_feedback(engine, out)
                _ask("Press Enter to continue...", input_fn)
                try:
                    engine.next()
                except QuizStateError as exc:  # defensive; should not happen
                    print(exc, file=out)
            _show_results(engine, out)
            again = _ask("\nPlay again? (y/n): ", input_fn).lower()
            if again in ("y", "yes"):
                engine.restart()
            else:
                print("Thanks for playing!", file=out)
                return
    except QuitQuiz:
        print("\nGoodbye!", file=out)


def main(argv=None, input_fn=input, out=sys.stdout):
    parser = argparse.ArgumentParser(description="Command-line quiz app.")
    parser.add_argument("file", nargs="?", default=str(DEFAULT_FILE), help="path to questions JSON file")
    parser.add_argument("--shuffle", action="store_true", help="randomize question and option order")
    args = parser.parse_args(argv)

    try:
        loaded = load_questions(args.file)
    except QuizLoadError as exc:
        print(f"Error: {exc}", file=out)
        return 1

    for warning in loaded.warnings:
        print(f"Warning: {warning}", file=out)

    engine = QuizEngine(loaded.questions, shuffle=args.shuffle)
    play(engine, input_fn=input_fn, out=out, title=loaded.title)
    return 0


if __name__ == "__main__":
    sys.exit(main())
