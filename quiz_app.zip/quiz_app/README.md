# Quiz App (Python CLI)

A command-line quiz that loads questions from `questions.json`, shows them one at a time, gives feedback, tracks the score and shows a pass/fail results screen. Python standard library only: **no installs needed**.

## Install and run

Requires Python 3.9 or newer (developed on 3.13).

```bash
git clone <your-repo-url> quiz_app    # or unzip the archive
cd quiz_app
python3 -m quiz                       # play with the bundled questions.json
```

Options:

```bash
python3 -m quiz path/to/other.json    # use a different question file
python3 -m quiz --shuffle             # stretch goal: shuffle questions and options
```

While playing: type a letter (`A`-`F`) or number to answer, `Enter` to continue, `r` to restart at any time, `q` (or Ctrl-C / Ctrl-D) to quit.

## Run the tests

```bash
python3 -m unittest discover -v
```

35 tests: scoring, navigation, locking, restart, shuffle correctness, loader validation and scripted end-to-end CLI sessions.

## Project layout

```
quiz/engine.py   Quiz state machine (scoring, navigation, restart). No I/O.
quiz/loader.py   Reads and validates questions.json. No I/O beyond the file read.
quiz/cli.py      Display and input only. Calls the engine; contains no quiz rules.
tests/           unittest tests for the three modules above
questions.json   10 Python-basics questions
```

## Stretch goals done

- **Shuffle** (`--shuffle`): randomizes question order and option order on every run and on every restart. The correct answer is remapped after shuffling and covered by a test.

No timer or high-score list (kept scope small to polish the core).

## Decisions

- **Malformed questions are skipped, not fatal.** A question is skipped (with a `Warning: Skipped question #N ...` line shown at startup saying why) if it is not an object, has empty/missing text, has no options or fewer than 2 or more than 6, has non-string options, or has an `answerIndex` that is not an integer or is outside the options range. One bad entry should not stop a whole quiz. If *no* valid question remains, the app shows an error and exits with code 1.
- **Missing, empty or invalid JSON, or an empty questions list:** a clear one-line `Error: ...` message (with line/column for bad JSON) and exit code 1. No traceback.
- **Single state owner:** all quiz state lives in one `QuizEngine` instance. There are no module-level mutable globals.
- **Answer locking:** once answered, `engine.answer()` raises `QuizStateError`, so a second answer can never change the score. The engine, not the UI, enforces this.
- **Moving on without answering:** the engine refuses (`next()` raises); the CLI also re-prompts on empty or invalid input instead of advancing.
- **Restart** is valid at any time (including mid-quiz) and fully resets score, position and the locked-answer flag. From the results screen it is offered as "Play again?".
- **Percentage** is shown rounded to a whole number, but pass/fail uses the exact value (`>= 60%`).
- Extra `id` values in the JSON are accepted but not required; the app does not depend on them.

## What I would improve with more time

- A simple web UI (Flask or FastAPI plus a small JS page) reusing the same engine unchanged.
- The per-question countdown timer and a persisted top-5 high-score list.
- Stricter schema validation with clearer per-field messages, and optional duplicate-option detection.
- Test the CLI's terminal handling (colors, Windows consoles) and add type hints plus a CI workflow running the tests.
