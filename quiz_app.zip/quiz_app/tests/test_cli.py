"""End-to-end CLI tests with scripted input (no real terminal needed)."""

import io
import json
import tempfile
import unittest
from pathlib import Path

from quiz.cli import main

QUESTIONS = {
    "title": "T",
    "questions": [
        {"id": 1, "question": "First?", "options": ["a", "b", "c"], "answerIndex": 0},
        {"id": 2, "question": "Second?", "options": ["a", "b"], "answerIndex": 1},
    ],
}


def run(file_path, inputs, extra_args=()):
    feed = iter(inputs)

    def fake_input(_prompt):
        try:
            return next(feed)
        except StopIteration:
            raise EOFError from None

    out = io.StringIO()
    code = main([str(file_path), *extra_args], input_fn=fake_input, out=out)
    return code, out.getvalue()


class CliTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "q.json"
        self.path.write_text(json.dumps(QUESTIONS), encoding="utf-8")

    def test_full_playthrough_with_pass(self):
        code, out = run(self.path, ["", "a", "", "b", "", "n"])
        self.assertEqual(code, 0)
        self.assertIn("This quiz has 2 questions", out)
        self.assertIn("Question 1 of 2", out)
        self.assertIn("Question 2 of 2", out)
        self.assertIn("Score: 2 / 2  (100%)", out)
        self.assertIn("PASS", out)

    def test_wrong_answer_shows_correct_option_and_fails(self):
        code, out = run(self.path, ["", "b", "", "a", "", "n"])
        self.assertIn("Wrong. The correct answer was A) a", out)
        self.assertIn("Score: 0 / 2  (0%)", out)
        self.assertIn("FAIL", out)

    def test_empty_and_invalid_input_does_not_advance(self):
        code, out = run(self.path, ["", "", "z", "9", "a", "", "b", "", "n"])
        self.assertIn("Please select an answer", out)
        self.assertIn("not a valid option", out)
        self.assertIn("Score: 2 / 2", out)

    def test_restart_from_results_resets_score(self):
        code, out = run(self.path, ["", "a", "", "b", "", "y", "b", "", "a", "", "n"])
        self.assertIn("Score: 2 / 2", out)
        self.assertIn("Score: 0 / 2", out)

    def test_restart_mid_quiz(self):
        code, out = run(self.path, ["", "a", "", "r", "a", "", "b", "", "n"])
        self.assertIn("Restarting quiz", out)
        self.assertIn("Score: 2 / 2", out)

    def test_bad_files_give_message_not_crash(self):
        missing = Path(self._tmp.name) / "missing.json"
        self.assertEqual(run(missing, [])[0], 1)
        self.path.write_text("{oops", encoding="utf-8")
        code, out = run(self.path, [])
        self.assertEqual(code, 1)
        self.assertIn("not valid JSON", out)

    def test_malformed_question_skipped_with_warning(self):
        data = json.loads(json.dumps(QUESTIONS))
        data["questions"].append({"id": 3, "question": "Bad", "options": ["a"], "answerIndex": 5})
        self.path.write_text(json.dumps(data), encoding="utf-8")
        code, out = run(self.path, ["q"])
        self.assertIn("Skipped question #3", out)
        self.assertIn("This quiz has 2 questions", out)

    def test_quit_and_eof_exit_cleanly(self):
        self.assertEqual(run(self.path, ["", "q"])[0], 0)
        self.assertEqual(run(self.path, [""])[0], 0)  # EOF mid-quiz


if __name__ == "__main__":
    unittest.main()
