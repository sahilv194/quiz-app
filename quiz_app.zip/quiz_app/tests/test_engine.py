import random
import unittest

from quiz.engine import FINISHED, IN_PROGRESS, QuizEngine, QuizStateError
from quiz.loader import Question


def make_questions(n=4):
    return [Question(i, f"Q{i}", ("a", "b", "c"), i % 3) for i in range(1, n + 1)]


def started(n=4, **kwargs):
    engine = QuizEngine(make_questions(n), **kwargs)
    engine.start()
    return engine


class ScoringTests(unittest.TestCase):
    def test_correct_answer_adds_one_point(self):
        engine = started()
        result = engine.answer(engine.current_question.answer_index)
        self.assertTrue(result.correct)
        self.assertEqual(engine.score, 1)

    def test_wrong_answer_adds_nothing_and_reports_correct_option(self):
        engine = started()
        q = engine.current_question
        wrong = (q.answer_index + 1) % len(q.options)
        result = engine.answer(wrong)
        self.assertFalse(result.correct)
        self.assertEqual(result.correct_text, q.options[q.answer_index])
        self.assertEqual(engine.score, 0)

    def test_answer_is_locked_after_submit(self):
        engine = started()
        q = engine.current_question
        engine.answer(q.answer_index)
        with self.assertRaises(QuizStateError):
            engine.answer((q.answer_index + 1) % 3)
        self.assertEqual(engine.score, 1)  # not changed or double counted

    def test_invalid_option_index_rejected(self):
        engine = started()
        for bad in (-1, 3, 99, "1", None, True):
            with self.assertRaises(QuizStateError):
                engine.answer(bad)
        self.assertFalse(engine.is_answered)


class NavigationTests(unittest.TestCase):
    def test_cannot_move_on_without_answering(self):
        engine = started()
        with self.assertRaises(QuizStateError):
            engine.next()
        self.assertEqual(engine.position, 1)

    def test_next_advances_position_and_clears_answer(self):
        engine = started()
        engine.answer(0)
        engine.next()
        self.assertEqual(engine.position, 2)
        self.assertFalse(engine.is_answered)

    def test_finishes_after_last_question_and_result_is_correct(self):
        engine = started(4)  # correct indexes: 1,2,0,1
        for _ in range(4):
            engine.answer(engine.current_question.answer_index)
            engine.next()
        self.assertEqual(engine.state, FINISHED)
        r = engine.result()
        self.assertEqual((r.score, r.total, r.percent), (4, 4, 100.0))
        self.assertTrue(r.passed)

    def test_pass_boundary_is_60_percent(self):
        for correct, expected in ((3, True), (2, False)):  # 3/5 = 60%, 2/5 = 40%
            engine = started(5)
            for i in range(5):
                q = engine.current_question
                pick = q.answer_index if i < correct else (q.answer_index + 1) % 3
                engine.answer(pick)
                engine.next()
            self.assertEqual(engine.result().passed, expected)

    def test_single_question_quiz_works(self):
        engine = started(1)
        engine.answer(engine.current_question.answer_index)
        engine.next()
        self.assertTrue(engine.is_finished)
        self.assertEqual(engine.result().percent, 100.0)

    def test_result_before_finish_raises(self):
        with self.assertRaises(QuizStateError):
            started().result()

    def test_empty_question_list_rejected(self):
        with self.assertRaises(ValueError):
            QuizEngine([])


class RestartTests(unittest.TestCase):
    def test_restart_after_finish_resets_everything(self):
        engine = started(2)
        for _ in range(2):
            engine.answer(engine.current_question.answer_index)
            engine.next()
        engine.restart()
        self.assertEqual(engine.state, IN_PROGRESS)
        self.assertEqual((engine.score, engine.position), (0, 1))
        self.assertFalse(engine.is_answered)

    def test_restart_mid_quiz_resets_score_position_and_answer(self):
        engine = started(4)
        engine.answer(engine.current_question.answer_index)
        engine.next()
        engine.answer(engine.current_question.answer_index)  # answered, not advanced
        engine.restart()
        self.assertEqual((engine.score, engine.position), (0, 1))
        self.assertFalse(engine.is_answered)
        engine.answer(engine.current_question.answer_index)  # answer unlocked again
        self.assertEqual(engine.score, 1)


class ShuffleTests(unittest.TestCase):
    def test_shuffled_options_keep_correct_answer_marked(self):
        qs = [Question(i, f"Q{i}", ("w", "x", "y", "z"), i % 4) for i in range(20)]
        originals = {q.text: q.options[q.answer_index] for q in qs}
        engine = QuizEngine(qs, shuffle=True, rng=random.Random(1))
        engine.start()
        seen = 0
        while not engine.is_finished:
            q = engine.current_question
            self.assertEqual(q.options[q.answer_index], originals[q.text])
            self.assertEqual(sorted(q.options), ["w", "x", "y", "z"])
            engine.answer(q.answer_index)
            engine.next()
            seen += 1
        self.assertEqual(seen, 20)
        self.assertEqual(engine.result().score, 20)

    def test_shuffle_changes_order_but_keeps_all_questions(self):
        engine = QuizEngine(make_questions(10), shuffle=True, rng=random.Random(3))
        engine.start()
        texts = []
        while not engine.is_finished:
            texts.append(engine.current_question.text)
            engine.answer(0)
            engine.next()
        self.assertCountEqual(texts, [f"Q{i}" for i in range(1, 11)])
        self.assertNotEqual(texts, [f"Q{i}" for i in range(1, 11)])


if __name__ == "__main__":
    unittest.main()
