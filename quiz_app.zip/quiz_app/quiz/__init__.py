"""Quiz app package: pure logic (engine, loader) kept separate from display (cli)."""
