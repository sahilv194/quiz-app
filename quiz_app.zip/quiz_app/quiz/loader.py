"""Load and validate questions from a JSON file.

Design decision: malformed questions are SKIPPED (not fatal) and reported back
to the caller as warnings, so one bad entry never kills the whole quiz. If no
valid question remains, QuizLoadError is raised with a clear message.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path

MIN_OPTIONS = 2
MAX_OPTIONS = 6


class QuizLoadError(Exception):
    """Raised when the question file cannot be turned into a playable quiz."""


@dataclass(frozen=True)
class Question:
    id: object
    text: str
    options: tuple
    answer_index: int


@dataclass
class LoadResult:
    title: str
    questions: list = field(default_factory=list)
    warnings: list = field(default_factory=list)


def _validate_question(raw, position):
    """Return (Question, None) if valid, else (None, reason)."""
    if not isinstance(raw, dict):
        return None, "not an object"

    text = raw.get("question")
    if not isinstance(text, str) or not text.strip():
        return None, "missing or empty 'question' text"

    options = raw.get("options")
    if not isinstance(options, list) or not options:
        return None, "missing or empty 'options'"
    if not all(isinstance(o, str) and o.strip() for o in options):
        return None, "options must be non-empty strings"
    if not (MIN_OPTIONS <= len(options) <= MAX_OPTIONS):
        return None, f"has {len(options)} options (expected {MIN_OPTIONS}-{MAX_OPTIONS})"

    idx = raw.get("answerIndex")
    # bool is a subclass of int in Python; reject it explicitly.
    if not isinstance(idx, int) or isinstance(idx, bool):
        return None, "'answerIndex' is missing or not an integer"
    if not (0 <= idx < len(options)):
        return None, f"'answerIndex' {idx} is outside the options range 0-{len(options) - 1}"

    qid = raw.get("id", position)
    return Question(qid, text.strip(), tuple(options), idx), None


def parse_questions(data):
    """Validate already-parsed JSON data and return a LoadResult."""
    if not isinstance(data, dict):
        raise QuizLoadError("The question file must contain a JSON object with a 'questions' list.")

    title = data.get("title")
    title = title.strip() if isinstance(title, str) and title.strip() else "Quiz"

    raw_questions = data.get("questions")
    if not isinstance(raw_questions, list):
        raise QuizLoadError("The question file has no 'questions' list.")
    if not raw_questions:
        raise QuizLoadError("The questions list is empty. Add at least one question.")

    result = LoadResult(title=title)
    for position, raw in enumerate(raw_questions, start=1):
        question, reason = _validate_question(raw, position)
        if question is None:
            label = raw.get("id", position) if isinstance(raw, dict) else position
            result.warnings.append(f"Skipped question #{position} (id {label}): {reason}.")
        else:
            result.questions.append(question)

    if not result.questions:
        raise QuizLoadError("No valid questions found. Every question in the file was malformed.")
    return result


def load_questions(path):
    """Read a JSON file from disk and return a LoadResult, or raise QuizLoadError."""
    path = Path(path)
    try:
        content = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise QuizLoadError(f"Question file not found: {path}") from None
    except (OSError, UnicodeDecodeError) as exc:
        raise QuizLoadError(f"Could not read question file {path}: {exc}") from None

    if not content.strip():
        raise QuizLoadError(f"Question file is empty: {path}")

    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise QuizLoadError(
            f"Question file is not valid JSON (line {exc.lineno}, column {exc.colno}): {exc.msg}"
        ) from None

    return parse_questions(data)
