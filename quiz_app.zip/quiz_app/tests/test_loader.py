import json
import tempfile
import unittest
from pathlib import Path

from quiz.loader import QuizLoadError, load_questions, parse_questions

GOOD = {"id": 1, "question": "Q?", "options": ["a", "b"], "answerIndex": 1}


class ParseTests(unittest.TestCase):
    def test_valid_file_loads(self):
        result = parse_questions({"title": "T", "questions": [GOOD]})
        self.assertEqual(result.title, "T")
        self.assertEqual(len(result.questions), 1)
        self.assertEqual(result.questions[0].answer_index, 1)
        self.assertEqual(result.warnings, [])

    def test_empty_questions_list_is_an_error(self):
        with self.assertRaises(QuizLoadError):
            parse_questions({"questions": []})

    def test_missing_questions_key_is_an_error(self):
        with self.assertRaises(QuizLoadError):
            parse_questions({"title": "x"})

    def test_top_level_not_object_is_an_error(self):
        with self.assertRaises(QuizLoadError):
            parse_questions([GOOD])

    def test_malformed_questions_are_skipped_with_warnings(self):
        bad = [
            {"id": 2, "question": "No options", "options": [], "answerIndex": 0},
            {"id": 3, "question": "Out of range", "options": ["a", "b"], "answerIndex": 2},
            {"id": 4, "question": "Negative", "options": ["a", "b"], "answerIndex": -1},
            {"id": 5, "question": "One option", "options": ["a"], "answerIndex": 0},
            {"id": 6, "question": "Seven", "options": list("abcdefg"), "answerIndex": 0},
            {"id": 7, "question": "Bad type", "options": ["a", "b"], "answerIndex": "1"},
            {"id": 8, "question": "Bool index", "options": ["a", "b"], "answerIndex": True},
            {"id": 9, "options": ["a", "b"], "answerIndex": 0},
            "not an object",
        ]
        result = parse_questions({"questions": [GOOD] + bad})
        self.assertEqual(len(result.questions), 1)
        self.assertEqual(len(result.warnings), len(bad))

    def test_all_malformed_is_an_error(self):
        with self.assertRaises(QuizLoadError):
            parse_questions({"questions": [{"question": "x", "options": [], "answerIndex": 0}]})

    def test_missing_title_gets_default(self):
        self.assertEqual(parse_questions({"questions": [GOOD]}).title, "Quiz")


class FileTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.dir = Path(self._tmp.name)

    def write(self, text):
        path = self.dir / "q.json"
        path.write_text(text, encoding="utf-8")
        return path

    def test_missing_file(self):
        with self.assertRaises(QuizLoadError) as ctx:
            load_questions(self.dir / "nope.json")
        self.assertIn("not found", str(ctx.exception))

    def test_empty_file(self):
        for content in ("", "   \n"):
            with self.assertRaises(QuizLoadError) as ctx:
                load_questions(self.write(content))
            self.assertIn("empty", str(ctx.exception))

    def test_invalid_json(self):
        with self.assertRaises(QuizLoadError) as ctx:
            load_questions(self.write("{not json"))
        self.assertIn("not valid JSON", str(ctx.exception))

    def test_valid_file_on_disk(self):
        path = self.write(json.dumps({"title": "T", "questions": [GOOD]}))
        self.assertEqual(len(load_questions(path).questions), 1)

    def test_bundled_questions_file_is_valid(self):
        bundled = Path(__file__).resolve().parent.parent / "questions.json"
        result = load_questions(bundled)
        self.assertGreaterEqual(len(result.questions), 8)
        self.assertEqual(result.warnings, [])


if __name__ == "__main__":
    unittest.main()
