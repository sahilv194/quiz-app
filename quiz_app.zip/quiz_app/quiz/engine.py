"""Quiz state machine. No input/output here, so it can be tested without a UI.

All quiz state lives in one QuizEngine instance (no module-level globals).

Lifecycle:  NOT_STARTED -> start() -> IN_PROGRESS -> (answer / next) -> FINISHED
restart() returns to IN_PROGRESS from the first question with everything reset.
"""

import random
from dataclasses import dataclass, replace

PASS_PERCENT = 60.0

NOT_STARTED = "not_started"
IN_PROGRESS = "in_progress"
FINISHED = "finished"


class QuizStateError(Exception):
    """Raised when an action is not allowed in the current state
    (for example, moving on before answering)."""


@dataclass(frozen=True)
class AnswerResult:
    correct: bool
    selected_index: int
    correct_index: int
    correct_text: str


@dataclass(frozen=True)
class QuizResult:
    score: int
    total: int
    percent: float
    passed: bool


class QuizEngine:
    def __init__(self, questions, shuffle=False, rng=None):
        questions = list(questions)
        if not questions:
            raise ValueError("QuizEngine needs at least one question.")
        self._source = questions
        self._shuffle = shuffle
        self._rng = rng or random.Random()
        self._reset_state()

    # ---- internal -------------------------------------------------------
    def _reset_state(self):
        self._order = list(self._source)
        self._index = 0
        self._score = 0
        self._last_answer = None
        self._state = NOT_STARTED

    # ---- read-only properties ------------------------------------------
    @property
    def total(self):
        return len(self._source)

    @property
    def state(self):
        return self._state

    @property
    def score(self):
        return self._score

    @property
    def position(self):
        """1-based number of the current question (for 'Question 3 of 10')."""
        return self._index + 1

    @property
    def is_answered(self):
        return self._last_answer is not None

    @property
    def last_answer(self):
        return self._last_answer

    @property
    def is_finished(self):
        return self._state == FINISHED

    @property
    def current_question(self):
        self._require(IN_PROGRESS, "There is no current question.")
        return self._order[self._index]

    # ---- actions --------------------------------------------------------
    def start(self):
        """Begin the quiz. Reshuffles each time if shuffle is enabled."""
        self._reset_state()
        if self._shuffle:
            self._rng.shuffle(self._order)
            self._order = [self._shuffle_options(q) for q in self._order]
        self._state = IN_PROGRESS

    def answer(self, selected_index):
        """Submit an answer for the current question. Locked once submitted."""
        question = self.current_question
        if self.is_answered:
            raise QuizStateError("This question is already answered; the answer is locked.")
        if isinstance(selected_index, bool) or not isinstance(selected_index, int):
            raise QuizStateError("Select an option by its number.")
        if not (0 <= selected_index < len(question.options)):
            raise QuizStateError("That option does not exist for this question.")

        correct = selected_index == question.answer_index
        if correct:
            self._score += 1
        self._last_answer = AnswerResult(
            correct=correct,
            selected_index=selected_index,
            correct_index=question.answer_index,
            correct_text=question.options[question.answer_index],
        )
        return self._last_answer

    def next(self):
        """Move to the next question, or finish after the last one."""
        self._require(IN_PROGRESS, "The quiz is not in progress.")
        if not self.is_answered:
            raise QuizStateError("Select an answer before moving on.")
        self._last_answer = None
        if self._index + 1 >= len(self._order):
            self._state = FINISHED
        else:
            self._index += 1
        return self._state

    def result(self):
        self._require(FINISHED, "The quiz is not finished yet.")
        percent = self._score / self.total * 100
        return QuizResult(
            score=self._score,
            total=self.total,
            percent=percent,
            passed=percent >= PASS_PERCENT,
        )

    def restart(self):
        """Full reset (valid at any time, including mid-quiz) and start again."""
        self.start()

    # ---- helpers --------------------------------------------------------
    def _shuffle_options(self, question):
        """Return a copy with options shuffled and answer_index remapped,
        so the correct answer is still marked correctly."""
        correct_text_pos = question.answer_index
        positions = list(range(len(question.options)))
        self._rng.shuffle(positions)
        return replace(
            question,
            options=tuple(question.options[p] for p in positions),
            answer_index=positions.index(correct_text_pos),
        )

    def _require(self, state, message):
        if self._state != state:
            raise QuizStateError(message)
